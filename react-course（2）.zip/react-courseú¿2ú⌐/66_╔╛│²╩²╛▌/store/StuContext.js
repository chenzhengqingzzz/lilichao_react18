import React from "react";

const StuContext = React.createContext({
    fetchData: () => {
    }
});

export default StuContext;
