import React from 'react';

const B = () => {
    console.log("组件B重新渲染");
    return (
        <div>
            组件B
        </div>
    );
};

export default B;
