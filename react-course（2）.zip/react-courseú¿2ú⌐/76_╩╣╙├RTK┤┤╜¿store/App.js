import React from 'react';
import './store/index';

const App = () => {
    return (
        <div>
         App
        </div>
    );
};

export default App;
