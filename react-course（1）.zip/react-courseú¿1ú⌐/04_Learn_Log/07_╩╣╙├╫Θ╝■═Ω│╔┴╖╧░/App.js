import Logs from "./Components/Logs/Logs";

const App = () => {
  return <div>
    <Logs/>
  </div>
};

// 导出App
export default App;
