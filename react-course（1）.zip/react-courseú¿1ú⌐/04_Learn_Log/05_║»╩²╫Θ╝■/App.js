const App = () => {
  return <div>我是App组件！</div>
};

// 导出App
export default App;
