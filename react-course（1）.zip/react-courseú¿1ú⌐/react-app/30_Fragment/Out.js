import React from 'react';

const Out = (props) => {
    return props.children;
};

export default Out;
