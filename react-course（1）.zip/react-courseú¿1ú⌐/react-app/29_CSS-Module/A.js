import React from 'react';
import classes from "./A.module.css";

const A = () => {
    return (
        <div>
            <p className={classes.p1}>我是A组件</p>
        </div>
    );
};

export default A;
