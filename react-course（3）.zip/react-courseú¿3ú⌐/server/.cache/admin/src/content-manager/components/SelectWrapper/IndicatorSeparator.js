const IndicatorSeparator = () => null;

export default IndicatorSeparator;
