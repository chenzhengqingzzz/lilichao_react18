export default {
  config: {
    locales: [
      'zh-Hans',
    ],
  },
  bootstrap(app) {
    console.log(app);
  },
};
