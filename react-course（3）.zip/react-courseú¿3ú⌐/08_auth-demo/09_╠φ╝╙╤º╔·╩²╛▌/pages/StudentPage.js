import React from 'react';
import StudentList from "../components/Student/StudentList";

const StudentPage = () => {
    return (
        <div>
            <StudentList/>
        </div>
    );
};

export default StudentPage;
