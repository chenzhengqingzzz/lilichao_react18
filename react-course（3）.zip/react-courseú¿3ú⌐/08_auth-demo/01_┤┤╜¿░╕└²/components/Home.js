import React from 'react';

const Home = () => {
    return (
        <div>
            <h2>这是主页</h2>
            <p>这个页面无需权限任何人都可以访问</p>
        </div>
    );
};

export default Home;
