import React from 'react';

const Profile = () => {
    return (
        <div>
            <h2>用户信息的页面</h2>
            <p>该页面只有在登录后才能查看</p>
        </div>
    );
};

export default Profile;
