import React from 'react';
import Profile from "../components/Profile";

const ProfilePage = () => {
    return (
        <div>
            <Profile/>
        </div>
    );
};

export default ProfilePage;
