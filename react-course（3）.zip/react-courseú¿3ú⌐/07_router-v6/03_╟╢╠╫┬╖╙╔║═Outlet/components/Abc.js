import React from 'react';

const Abc = () => {
    return (
        <div>
            <h2>Abc组件</h2>
        </div>
    );
};

export default Abc;
