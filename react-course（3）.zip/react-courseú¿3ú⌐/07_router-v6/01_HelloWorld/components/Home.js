import React from 'react';

const Home = () => {
    return (
        <div>
            <h2>主页</h2>
            <p>主页的内容真精彩！</p>
        </div>
    );
};

export default Home;
