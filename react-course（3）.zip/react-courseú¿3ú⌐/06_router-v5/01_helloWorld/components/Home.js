import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>主页，主页中有非常非常好的内容</h1>
        </div>
    );
};

export default Home;
