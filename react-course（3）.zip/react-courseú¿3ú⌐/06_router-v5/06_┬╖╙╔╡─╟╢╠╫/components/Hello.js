import React from 'react';

const Hello = () => {
    return (
        <div>
           <h2>Hello组件</h2>
        </div>
    );
};

export default Hello;
