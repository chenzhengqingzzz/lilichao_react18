import React from 'react';

const Login = () => {
    return (
        <div>
            <h2>登录页面</h2>
        </div>
    );
};

export default Login;
